﻿namespace ApiOAuthEmpleados.Models
{
    public class LoginModel
    {
        public string Username { get; set; }

        public int Password { get; set; }    
    }
}
